package cmps252.assignment3;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
public class MyFrame extends JFrame implements ActionListener {
	 JButton button1;
	 JButton button2;
	 JMenuBar mb;
		JMenu m1;
		JMenuItem m11;
		JMenu m2 ;
		JMenuItem m12;
	MyFrame(String title ) {
		super( title );
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(300,300);
		this.getContentPane().setLayout(new FlowLayout());
		 button1 = new JButton("Press Me");
		this.getContentPane().add(button1);
		this.setVisible(true);
		 button2 = new JButton("Button 2");

		this.getContentPane().add(button2);
		button1.addActionListener(this);
		button2.addActionListener(this);
		 mb = new JMenuBar();
		 m1 = new JMenu("FILE");
		 mb.add(m1);
		 m2 = new JMenu("HELP");
	    mb.add(m2);
		m11 = new JMenuItem("Open");
	   	m1.add(m11);
	   	m12 = new JMenuItem("Save As");
	   	m1.add(m12);
	   	
		this.setJMenuBar(mb);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
	 if (e.getSource() instanceof JButton) {
		JButton b = (JButton) e.getSource();
		if (b==button1)
		{
		JOptionPane.showConfirmDialog(this, "You clicked Button1","Button Click Event Handler", JOptionPane.PLAIN_MESSAGE);
		}
		else if (b==button2)
		{
		JOptionPane.showConfirmDialog(this, "You clicked Button2","Button Click Event Handler",
		JOptionPane.PLAIN_MESSAGE);
		}
	 }
		
	 else if (e.getSource() instanceof JMenuItem) {
			JMenuItem m = (JMenuItem) e.getSource();
			if (m==m11)
			{
			JOptionPane.showConfirmDialog(this, "You clicked Open","Button Click Event Handler", JOptionPane.PLAIN_MESSAGE);
		}
	 }
	}
}
